﻿C Hardware Performance Analyzer · v0.1.0-preview · Windows x64
Copyright © 2026 Manfred Mertens
(c) Manfred Mertens 2026-11-21

Extract the entire ZIP into a local folder. Keep both EXEs and DLLs together.
Open hardware_gui.exe. Select "Benchmark starten" to measure performance or
"SIMD + Neuron anzeigen" to explore eight weighted inputs, bias and ReLU.
The interface and console output are in German.

The benchmark adds one to 4,194,304 floating-point values in 100 passes.
Times are medians of three runs. Lower is better. Compare single-thread
and OpenMP CPU times with the optional OpenCL GPU time including transfers.
Device kernel time excludes transfers. Results describe this workload.
For a CPU-only run, open PowerShell in the extracted folder and enter:
  .\hardware_analyse.exe --cpu-only

Tested on Windows 11 Pro x64 build 26300 with an Intel Core i5-10310U and
Intel UHD Graphics, driver 31.0.101.2135, OpenCL 3.0 NEO. Both CPU-only
and automatic CPU/GPU runs completed with zero numerical errors. Testing
on a clean installation, Windows 10 and physical non-AVX hardware is pending.
The preview includes both non-system runtime DLLs. GPU measurements require
a compatible OpenCL driver. The executables are unsigned.

Free for private and professional use. See LIZENZ_FREEWARE.txt for the
application terms and THIRD_PARTY_NOTICES.txt for runtime licenses and sources.
