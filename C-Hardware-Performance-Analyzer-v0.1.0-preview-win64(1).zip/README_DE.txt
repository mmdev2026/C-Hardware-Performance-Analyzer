﻿C Hardware Performance Analyzer · v0.1.0-preview · Windows x64
Copyright © 2026 Manfred Mertens
(c) Manfred Mertens 2026-11-21

Start: ZIP über „Alle extrahieren“ in einen lokalen Ordner entpacken.
hardware_gui.exe öffnen. Beide EXE-Dateien und beide DLLs zusammenlassen.
„Benchmark starten“ misst CPU und gegebenenfalls GPU. „SIMD + Neuron anzeigen“
öffnet die zweite Ansicht. Mit dem Mausrad lässt sich die Seite verschieben.

Der Test addiert bei 4.194.304 Gleitkommazahlen jeweils 100-mal eins. Der
Median aus drei Läufen liefert die Vergleichszeit. Kleinere Werte sind besser.
Ein CPU-Lauf verwendet einen Thread, der zweite verteilt die Arbeit mit
OpenMP auf mehrere Threads. Bei kompatiblem OpenCL-Treiber führt die GPU
dieselbe Aufgabe aus. Für den Vergleich mit der CPU ist die GPU-Zeit mit
Hin- und Rücktransfer besonders aussagekräftig. Rechenfehler machen die
betroffene Messung unbrauchbar. Der Vergleich gilt für diese Aufgabe.

In der Neuronenansicht werden acht Eingaben mit ihren Gewichten multipliziert.
AVX erledigt die acht Produkte als Vektoroperation. Für Rechner ohne
nutzbares AVX ist ein skalarer Rechenpfad vorgesehen. Auf die Summe plus
Bias wird die Aktivierungsfunktion ReLU angewendet.

Konsolenbetrieb in PowerShell aus dem entpackten Ordner:
  .\hardware_analyse.exe
CPU-Messung ohne Zugriff auf den OpenCL-Treiber:
  .\hardware_analyse.exe --cpu-only

Getestet auf Windows 11 Pro x64, Build 26300, Intel Core i5-10310U, Intel UHD
Graphics, Intel-Treiber 31.0.101.2135, OpenCL 3.0 NEO. CPU-only und CPU/GPU
waren dort fehlerfrei. Der Lauf auf dem Entwicklungsrechner verwendete beim
Test nur den Windows-Systemsuchpfad. Der Start auf einer separaten sauberen
Windows-Installation, Windows 10 x64 und einer physischen CPU ohne AVX
ist noch offen. Diese Prüffassung enthält die beiden benötigten
Nicht-System-DLLs. Eine kompatible GPU mit OpenCL-Treiber ist optional.
Die EXEs sind unsigniert.

Kostenlose private und berufliche Nutzung. Bedingungen in LIZENZ_FREEWARE.txt.
Lizenztexte der Laufzeitbibliotheken befinden sich unter Lizenzen/.
